Inicializar com o comando "metodoPontoFixo()" sem as aspas no terminal.
Após isso digite a aproximação inicial e a quantidade de iterações.