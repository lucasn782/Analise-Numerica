#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int Iter;
float x;
int numIter;

int main(void){
	printf("Digite o valor de x(0):");
	scanf("%f", &x);
	printf("Digite o n�mero de Itera��es:");
	scanf("%d", &numIter);
	for (Iter = 0; Iter < numIter; Iter++){
		x = x - (x - cos(x))/(1 + sin(x));
		printf("Valor de x(%d) = %f\n", Iter, x);
	}
	printf("O valor da raiz �: %f\n", x);
	printf("N�mero de Itera��es  = %d\n", Iter);
	system("pause");
	return 0;
}
